import compileall
from sys import argv
compileall.compile_file(argv[1])
